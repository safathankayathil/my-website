list =[10, 20, 30, 40, 50]
sum = 0
for i in list:
    sum = sum+i

print(sum)