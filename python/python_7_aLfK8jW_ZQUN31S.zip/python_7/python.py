list = [11, 5, 17, 18, 23, 50]
for e in list:
    if e%2==0:
        list.remove(e)
print(list) 