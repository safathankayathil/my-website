s = "Misiriya Abdulrahman"
print(s[0:8])
print(s[9:20])