list = [10,11,12,13,14,15]
length = len(list)
start = list[0]
list[0] = list[length-1]
list[length-1] = start
print(list)