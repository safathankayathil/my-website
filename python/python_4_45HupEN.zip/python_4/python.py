string = "hello556478195fjds"

sum = 0
for x in string:
    if x.isdigit():
        sum = sum+int(x)

print(sum)