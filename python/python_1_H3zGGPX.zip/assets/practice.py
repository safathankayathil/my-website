string = "Welcome to Talrop"

# 1, To show type of string

 print(type(string))
<class 'str'>


# 2, Print the first character from the string

print(string[0])
W


# 3, Split the string in to words

print(string.split())
['Welcome', 'to', 'Talrop']

# 4, Convert the String to Uppercase

print(string.upper())
'WELCOME TO TALROP'



# 5, Convert the String to Lowercase

print(string.lower())
'welcome to talrop'


# 6, Check whether "Talrop" is in the string.

print(string.find("Talrop"))
11


# 7, How many times "Talrop" repeated in this string 

print(string.count("Talrop"))
1


# 8, Capitalize the first letter 

print(string.capitalize())
Welcome to talrop

# 9, Find length of the string

print(len(string))
17



# 10, Replace the spaces with hyphen(-)

print(string.replace(" ","_"))
Welcome_to_Talrop
